package encapsulation;

//final - final keyword can be used with the class. This means the class which is defined as final cannot be inherited
//final can be used with the method - If a method is declared as final then that method CANNOT be Overriden
final public class Addition {
	//Public methods can be accessed from ANYWHERE
	public void add(int x, int y) {
		int c = x + y;
		System.out.println("Sum = " + c);
	}
	
	//A private method cannot be accessed OUTSIDE this class
	//Private Methods can be called within this class.
	private void print() {
		System.out.println("Hello...");
	}
	
	//Only the class which is inside same package can access this method
	void test() {
		//Can i call print() here??
		print(); //YES
	}
	
	protected void callMe() { //This method should be accessed only by Sub classes
		
	}
}
