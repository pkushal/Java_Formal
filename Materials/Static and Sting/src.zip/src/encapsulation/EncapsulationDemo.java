package encapsulation;


/*
 * Encapsulation uses below 3 Keywords
 * 1. public: FULL ACCESS - ANy class Defined INSIDE same package OR OUTSIDE the package can access this Method whic is defined as public
 * 2. private: A private (Member) method/instance-variable cannot be accessed OUTSIDE that class
 * 3. protected: A method declared as protected can b accessed only by Subclasses. This cannot be accessed
 *    by the class outside the package.
 * 4. Default - Its not a keyword. This is one of the access specifier
 *     Any method defined as default can be accessed OUTSIDE the class
 *     But INSIDE same package
 */
public class EncapsulationDemo {
	public static void main(String[] args) {
		Addition ob = new Addition();
		ob.add(10, 20);//Yes, this can be accessed as the access specifier is 'Default'
		//ob.print(); //print method is private and hence not visible
		ob.test(); //Access specifier is 'Default'
	}
}
