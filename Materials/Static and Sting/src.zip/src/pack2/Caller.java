package pack2; // Mention the name of the package inside which you have placed the Java CLass file

import pack1.MyClass;
import pack1.pack11.MyClass11;
import pack1.pack11.pack12.MyClass112;
import encapsulation.Addition;
//Import ALL the "classes" from pack1.pack11
//REM: DO NOT USE '*' always. Use '*' ONLY if you are using ALL classes from that Package
//REM: Using '*' in  import is not Suggested
//Reason - When we use '*' Java will include/Load ALL classes and incase all classes are not used.
//Un-necessery memory will be consumed.

//Rem: The package declaration should be the First line in Java code

//import  pack1.MyClass;//Import the class from another package to this current class
//In above import, Java will include the class 'MyClass' here and hence the Caller class can
//create an Object of MyClass
//import pack1.pack11.MyClass11; 
//You need to give Complete Package path to import a Class

public class Caller {

	public static void main(String[] args) {
		MyClass ob = new MyClass();
		//pack1.MyClass ob = new pack1.MyClass(); //This is also Valid
		//ob.print();
		
		MyClass11 ob1 = new MyClass11();
		MyClass112 ob2 = new MyClass112();
		//import pack1.pack11.* will only import the CLASS files under this package
		//It will NOT import the SubPackages
		
		Addition addObj = new Addition();
		addObj.add(10, 20);
		//print() method is not visible here. The reason is add() method has default access specifier
		//add() method is now visible as it is 'public'
		addObj.test(); //test() cannot be accessed.
		addObj.callMe(); //Cannot access this method as its Protected and Protected members can nbe calleed only from Sub classes
		
	}
}
