package pack2;

import encapsulation.Addition;

public class MyClass1 extends Addition {
	
	void call() {
		add(10, 20); //add() method is public and hence an be accssed here
		//test(); //test() mthod is default and cannot be accessed here
		//print(); //print() cannot be accessed as its private
		callMe(); //this method can be accssed ONLY by Sub class as its protected
	}
}
