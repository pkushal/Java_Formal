


public class WhileLoop {
	   public static void main(String args[]) {
		      int x = 10; //Initialization
		      
		      //Loop1 - x = 10, x = 20
		      while( x <= 20 ) { //Condition Check
		         System.out.println("value of x : " + x );
		         x ++; //x is incremented by 1 - New value of x = 20 (Increment/Decrement)
		      }
		   }
}

