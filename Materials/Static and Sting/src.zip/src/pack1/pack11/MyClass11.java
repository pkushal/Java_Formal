package pack1.pack11;

public class MyClass11 {
	
	void test() {
		System.out.println("From MyClass11");
	}
}
