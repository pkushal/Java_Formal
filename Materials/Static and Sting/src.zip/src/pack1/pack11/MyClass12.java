package pack1.pack11;

public class MyClass12 {

}
