package pack1.pack11.pack12;

public class MyClass112 {

}
