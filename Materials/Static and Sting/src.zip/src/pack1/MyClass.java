package pack1;

public class MyClass {
	void print() {
		System.out.println("Hello");
	}
}
