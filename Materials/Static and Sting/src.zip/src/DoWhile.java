


public class DoWhile {
	   public static void main(String args[]){
		      int x = 10;

		      do{
		         System.out.println("value of x : " + x );
		         x++;
		      }while( x <= 20 );
		   }
}
