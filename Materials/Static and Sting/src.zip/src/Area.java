
public class Area {
	
	int l = 10;
	int b = 20;
	void calculateArea() {
		int a = l * b;
		System.out.println("Area Class - calculateArea Method: " + a);
	}
	void m1() {
		System.out.println("Area Class - m1 Method");
	}
	void m2() {
		System.out.println("Area Class - m2 Method");
	}
}
